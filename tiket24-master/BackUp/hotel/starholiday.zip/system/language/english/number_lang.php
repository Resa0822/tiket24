<?php

$lang['terabyte_abbr'] = "TB";
$lang['gigabyte_abbr'] = "GB";
$lang['megabyte_abbr'] = "MB";
$lang['kilobyte_abbr'] = "KB";
$lang['bytes'] = "Bytes";

/* End of file number_lang.php */
/* Location: ./system/language/english/number_lang.php */