<?php
if( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Flight extends CI_Controller {
 
    function __construct() {
        parent::__construct(); 
		$this->load->model('flight_model');		
		
     } 
 
     public function index() {
     	$currentDate = date('Y-m-d');
		$lastDate = date('Y-m-d', strtotime('+30 day' . $currentDate)); 
		$departureAirportCode = 'CGK';
		$arrivalAirportCode = 'DPS';
		$adult = 1;
		$child = 0;
		$infant = 0;
		$searchVersion = 3;
		$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$departureAirportCode.'&a='.$arrivalAirportCode.'&date='.$currentDate.'&ret_date='.$lastDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		$jsonUrl = file_get_contents($url, false);
		$getFlightNfo = json_decode($jsonUrl, true);
		$lftCntntDta['cheapFlight'] = $getFlightNfo;
		$lftCntntDta['departuresSelect'] = $this->flight_model->get_airports_groupby_countryid();
		$lftCntntDta['arrivalsSelect'] = $this->flight_model->get_airports_groupby_countryid();
		$hdrCntntDta['topNavActive'] = 'flight';
		$data['footercontent'] = $this->load->view('frontend/footer-content','',true);
		$data['headercontent'] = $this->load->view('frontend/header-content',$hdrCntntDta,true);
		$data['slidercontent'] = 'none';
		$data['rightcontent'] = $this->load->view('frontend/flight/flight-right-content','',true);
		$data['leftcontent'] = $this->load->view('frontend/home-left-content',$lftCntntDta,true);
	    $data['title'] = "Starholiday | Flights";
        $this->load->view('frontend-template', $data);
    }

	function cheap_flight_fare(){
		$dprtrCode = 'CGK';
		$arrvlCode = 'SRG';
		$dprtrDate = '2014-09-17';
		$rtrnDate = '';
		$adult = 1;
		$child = 0;
		$infant = 0;
		
		$searchVersion = 3;
		/* start collect data */
		$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode.'&a='.$arrvlCode.'&date='.$dprtrDate.'&ret_date='.$rtrnDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		$jsonUrl = file_get_contents($url, false);
		$getFlightNfo = json_decode($jsonUrl, true);
		$allDepartures = $getFlightNfo['departures']['result'];
		$currency = $getFlightNfo['diagnostic']['currency'];
		$i=0;
		foreach($allDepartures as $rowDprtr){
			$departuresFlightnumber = $getFlightNfo['departures']['result'][$i]['flight_number'];
			$departTime= $getFlightNfo['departures']['result'][$i]['simple_departure_time'];
			$arriveTime= $getFlightNfo['departures']['result'][$i]['simple_arrival_time'];
			$flghtImage = $getFlightNfo['departures']['result'][$i]['image'];
			$flightFasility = $getFlightNfo['departures']['result'][$i]['stop'];
			$flightPrice = $getFlightNfo['departures']['result'][$i]['price_value'];
			$isPromo = $getFlightNfo['departures']['result'][$i]['is_promo'];
			$departureCity = $getFlightNfo['departures']['result'][$i]['departure_city_name'];
			$arrivalCity = $getFlightNfo['departures']['result'][$i]['arrival_city_name'];
			$html = '<table class="table">
				<tr>
					<td><img src="'.$flghtImage.'" /> '.$departuresFlightnumber.'</td>
					<td>'.$departTime.'</td>
					<td>'.$arriveTime.'</td>
					<td>'.$flightFasility.'</td>
					<td>'.$currency.' '.number_format($flightPrice).'</td>
				</tr>
			</table>';
				echo $html.'<br />';
		$i++;	
		}
		/* ==================================================== */
		$dprtrCode_1 = 'CGK';
		$arrvlCode_1 = 'DPS';
		$dprtrDate_1 = '2014-09-17';
		$rtrnDate_1 = '';
		$adult_1 = 1;
		$child_1 = 0;
		$infant_1 = 0;
		
		$searchVersion_1 = 3;
		/* start collect data */
		$url_1 = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode_1.'&a='.$arrvlCode_1.'&date='.$dprtrDate_1.'&ret_date='.$rtrnDate_1.'&adult='.$adult_1.'&child='.$child_1.'&infant='.$infant_1.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		$jsonUrl_1 = file_get_contents($url_1, false);
		$getFlightNfo_1 = json_decode($jsonUrl_1, true);
		$allDepartures_1 = $getFlightNfo_1['departures']['result'];
		$currency_1 = $getFlightNfo_1['diagnostic']['currency'];
		$i_1 = 0;
		foreach($allDepartures_1 as $rowDprtr_1){
			$departuresFlightnumber_1 = $getFlightNfo_1['departures']['result'][$i_1]['flight_number'];
			$departTime_1 = $getFlightNfo_1['departures']['result'][$i_1]['simple_departure_time'];
			$arriveTime_1 = $getFlightNfo_1['departures']['result'][$i_1]['simple_arrival_time'];
			$flghtImage_1 = $getFlightNfo_1['departures']['result'][$i_1]['image'];
			$flightFasility_1 = $getFlightNfo_1['departures']['result'][$i_1]['stop'];
			$flightPrice_1 = $getFlightNfo_1['departures']['result'][$i_1]['price_value'];
			$isPromo_1 = $getFlightNfo_1['departures']['result'][$i_1]['is_promo'];
			$departureCity_1 = $getFlightNfo_1['departures']['result'][$i_1]['departure_city_name'];
			$arrivalCity_1 = $getFlightNfo_1['departures']['result'][$i_1]['arrival_city_name'];
			$html_1 = '<table class="table">
				<tr>
					<td><img src="'.$flghtImage_1.'" /> '.$departuresFlightnumber_1.'</td>
					<td>'.$departTime_1.'</td>
					<td>'.$arriveTime_1.'</td>
					<td>'.$flightFasility_1.'</td>
					<td>'.$currency_1.' '.number_format($flightPrice_1).'</td>
				</tr>
			</table>';
				echo $html_1.'<br />';
		$i_1++;	
		}
		
	}
	
	function search_flight_oneway(){
		$dprtrCode = 'CGK';
		$arrvlCode = 'SRG';
		$dprtrDate = '2014-09-17';
		$rtrnDate = '';
		$adult = 1;
		$child = 0;
		$infant = 0;
		
		$searchVersion = 3;
		/* start collect data */
		$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode.'&a='.$arrvlCode.'&date='.$dprtrDate.'&ret_date='.$rtrnDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		$jsonUrl = file_get_contents($url, false);
		$getFlightNfo = json_decode($jsonUrl, true);
		$allDepartures = $getFlightNfo['departures']['result'];
		$currency = $getFlightNfo['diagnostic']['currency'];
		$i=0;
		foreach($allDepartures as $rowDprtr){
			$departuresFlightnumber = $getFlightNfo['departures']['result'][$i]['flight_number'];
			$departTime= $getFlightNfo['departures']['result'][$i]['simple_departure_time'];
			$arriveTime= $getFlightNfo['departures']['result'][$i]['simple_arrival_time'];
			$flghtImage = $getFlightNfo['departures']['result'][$i]['image'];
			$flightFasility = $getFlightNfo['departures']['result'][$i]['stop'];
			$flightPrice = $getFlightNfo['departures']['result'][$i]['price_value'];
			$isPromo = $getFlightNfo['departures']['result'][$i]['is_promo'];
			$departureCity = $getFlightNfo['departures']['result'][$i]['departure_city_name'];
			$arrivalCity = $getFlightNfo['departures']['result'][$i]['arrival_city_name'];
			$html = '<table class="table">
				<tr>
					<td><img src="'.$flghtImage.'" /> '.$departuresFlightnumber.'</td>
					<td>'.$departTime.'</td>
					<td>'.$arriveTime.'</td>
					<td>'.$flightFasility.'</td>
					<td>'.$currency.' '.number_format($flightPrice).'</td>
				</tr>
			</table>';
				echo $html.'<br />';
		$i++;	
		}
	}
	function search_flight_roundtrip(){
		$dprtrCode = 'CGK';
		$arrvlCode = 'SRG';
		$dprtrDate = '2014-09-17';
		$rtrnDate = '2014-09-25';
		$adult = 1;
		$child = 0;
		$infant = 0;
		
		$searchVersion = 3;
		/* start collect data */
		$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode.'&a='.$arrvlCode.'&date='.$dprtrDate.'&ret_date='.$rtrnDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		$jsonUrl = file_get_contents($url, false);
		$getFlightNfo = json_decode($jsonUrl, true);
		$allDepartures = $getFlightNfo['departures']['result'];
		$allReturns = $getFlightNfo['returns']['result'];
		$currency = $getFlightNfo['diagnostic']['currency'];
		$i=0;
		foreach($allDepartures as $rowDprtr){
			$departuresFlightnumber = $getFlightNfo['departures']['result'][$i]['flight_number'];
			$departTime= $getFlightNfo['departures']['result'][$i]['simple_departure_time'];
			$arriveTime= $getFlightNfo['departures']['result'][$i]['simple_arrival_time'];
			$flghtImage = $getFlightNfo['departures']['result'][$i]['image'];
			$flightFasility = $getFlightNfo['departures']['result'][$i]['stop'];
			$flightPrice = $getFlightNfo['departures']['result'][$i]['price_value'];
			$isPromo = $getFlightNfo['departures']['result'][$i]['is_promo'];
			
			$html = '<table class="table">
				<tr>
					<td><img src="'.$flghtImage.'" /> '.$departuresFlightnumber.'</td>
					<td>'.$departTime.'</td>
					<td>'.$arriveTime.'</td>
					<td>'.$flightFasility.'</td>
					<td>'.$currency.' '.number_format($flightPrice).'</td>
				</tr>
			</table>';
				echo $html.'<br />';
		$i++;	
		}
		
	}

	function cheap_flight_sub_to_cgk(){
		$nowDate = date('d');
		$lastDate  = date('t');
		$year = date('Y');
		$month = date('m');
		$dprtrCode = 'SUB';
		$arrvlCode = 'CGK';
		//$dprtrDate = '2014-09-23';//date('Y-m-d');
		//$rtrnDate = date('Y-m-t');
		$adult = 1;
		$child = 0;
		$infant = 0;
		$searchVersion = 3;
		$endLoop = $lastDate - $nowDate;
		for($i=$nowDate;$i<=$lastDate;$i++){
			$dprtrDate = $year.'-'.$month.'-'.$i;
			$rtrnDate = '';
			$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode.'&a='.$arrvlCode.'&date='.$dprtrDate.'&ret_date='.$rtrnDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		
			$jsonUrl = file_get_contents($url, false);
			$getFlightNfo = json_decode($jsonUrl, true);
			$j=0;
			$hasil = $getFlightNfo['departures']['result'];
			$currency = $getFlightNfo['diagnostic']['currency'];
			$departDate = $getFlightNfo['search_queries']['date'];
			foreach($hasil as $rowDprtr){
				$departuresFlightnumber = $getFlightNfo['departures']['result'][$j]['flight_number'];
				$departTime= $getFlightNfo['departures']['result'][$j]['simple_departure_time'];
				$arriveTime= $getFlightNfo['departures']['result'][$j]['simple_arrival_time'];
				$flghtImage = $getFlightNfo['departures']['result'][$j]['image'];
				$flightFasility = $getFlightNfo['departures']['result'][$j]['stop'];
				$flightPrice = $getFlightNfo['departures']['result'][$j]['price_value'];
				$isPromo = $getFlightNfo['departures']['result'][$j]['is_promo'];
				
				$html = '<table class="table">
					<tr>
						<td style="vertical-align:middle;"><img src="'.$flghtImage.'" /> '.$departuresFlightnumber.'</td>
						<td>'.$departTime.'</td>
						<td>'.$arriveTime.'</td>
						<td>'.$flightFasility.'</td>
						<td>'.$currency.' '.number_format($flightPrice).'</td>
						<td>'.$departDate.'</td>
					</tr>
				</table>';
				//if($isPromo == 1){
					echo $html.'<br />';
				//}
					
			$j++;	
			}
			
		}
		
		/* start collect data */
		/*
		$url = 'http://'.$this->get_api_domain().'/search/flight?d='.$dprtrCode.'&a='.$arrvlCode.'&date='.$dprtrDate.'&ret_date='.$rtrnDate.'&adult='.$adult.'&child='.$child.'&infant='.$infant.'&token='.$this->get_token().'&v='.$searchVersion.'&output=json';
		
		$jsonUrl = file_get_contents($url, false);
		$getFlightNfo = json_decode($jsonUrl, true);
		$i=0;
		$hasil = $getFlightNfo['departures']['result'];
		$currency = $getFlightNfo['diagnostic']['currency'];
		$departDate = $getFlightNfo['search_queries']['date'];
		foreach($hasil as $rowDprtr){
			$departuresFlightnumber = $getFlightNfo['departures']['result'][$i]['flight_number'];
			$departTime= $getFlightNfo['departures']['result'][$i]['simple_departure_time'];
			$arriveTime= $getFlightNfo['departures']['result'][$i]['simple_arrival_time'];
			$flghtImage = $getFlightNfo['departures']['result'][$i]['image'];
			$flightFasility = $getFlightNfo['departures']['result'][$i]['stop'];
			$flightPrice = $getFlightNfo['departures']['result'][$i]['price_value'];
			$isPromo = $getFlightNfo['departures']['result'][$i]['is_promo'];
			
			$html = '<table class="table">
				<tr>
					<td><img src="'.$flghtImage.'" /> '.$departuresFlightnumber.'</td>
					<td>'.$departTime.'</td>
					<td>'.$arriveTime.'</td>
					<td>'.$flightFasility.'</td>
					<td>'.$currency.' '.number_format($flightPrice).'</td>
					<td>'.$departDate.'</td>
				</tr>
			</table>';
			if($isPromo == 1){
				echo $html.'<br />';
			}
				
		$i++;	
		}
		 * */
		 
	}
	 
	function get_api_domain(){
		$APIdomain = $this->flight_model->get_api_domain();
		return $APIdomain;
	}
 
     function get_token(){
		$APIsecretKey = $this->flight_model->get_api_secret_key();
		$APIdomain = $this->flight_model->get_api_domain();
		$url = 'https://'.$APIdomain.'/apiv1/payexpress?method=getToken&secretkey='.$APIsecretKey.'&output=json';
		$jsonUrl = file_get_contents($url, False);
		$getToken = json_decode($jsonUrl, true);
		$flightApiToken = $getToken['token'];
		return $flightApiToken;
	} 
 
}
?>