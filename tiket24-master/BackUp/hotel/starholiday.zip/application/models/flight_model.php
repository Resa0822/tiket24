<?php
class Flight_model extends CI_Model{
	function __construct()
	{
		parent::__construct();
	}
	
	function get_api_secret_key(){
		$qry = $this->db->select('*')
		->from('settings')
		->where('API_provider', 'tiket')
		->where('setting_name', 'flight_api_secret_key')
		->get();
		$secretKey = $qry->row();
		return $secretKey->setting_value;
	}
	function get_api_domain(){
		$qry = $this->db->select('*')
		->from('settings')
		->where('API_provider', 'tiket')
		->where('setting_name', 'api_domain')
		->get();
		$apiDomain = $qry->row();
		return $apiDomain->setting_value;
	}
	function get_airports_groupby_countryid()
	{
		$this->db->select('*');
		$this->db->from('airports');
		$this->db->group_by('country_id');
		$qry = $this->db->get();
		return $qry->result();
	}
}
?>