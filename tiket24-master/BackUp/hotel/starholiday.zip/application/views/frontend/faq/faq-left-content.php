<div class="panel panel-primary costumpanel boxshadow" >
<div class="panel-heading costum_panel_head" style="background:#1792bc">
	<h3 class="panel-title"><b>FAQ Left Menu</b></h3>
</div>
<div class="panel-body">
Left Content
</div>
</div>

  