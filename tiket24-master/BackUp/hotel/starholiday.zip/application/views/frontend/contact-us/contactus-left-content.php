<div class="panel panel-primary costumpanel visible-md visible-lg boxshadow" id="flightfarebox" >
<div class="panel-heading costum_panel_head" style="background:#1792bc">
	<h3 class="panel-title" id="cheapest_flight_flare-header-panel-font" ><b>Our Channels</b></h3>
</div>
<div class="panel-body">
    <div style="padding-bottom:10px;"><img src="<?php echo base_url(); ?>assets/images/logos/facebook.png" alt="facebook logo" border="0" /></div>
    <div style="padding-bottom:10px;"><img src="<?php echo base_url(); ?>assets/images/logos/twitter.png" alt="twitter logo" border="0" /></div>
    <div style="padding-bottom:10px;"><img src="<?php echo base_url(); ?>assets/images/logos/instagram.png" alt="instagram logo" border="0" /></div>
</div>
</div>
