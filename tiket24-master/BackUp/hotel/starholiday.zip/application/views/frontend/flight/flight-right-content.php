<style>
.prevSlideFlight{
position:relative; background-color:#60d9ec; padding:25px 10px 25px 10px; vertical-align:middle; margin:0px; cursor: pointer; color:#1792bc; font-weight: bold; font-size:16px; display:inline-block;
}
.prevSlideFlight:hover{
position:relative; background-color:#1792bc; padding:25px 10px 25px 10px; vertical-align:middle; margin:0px; cursor: pointer; color:#ffffff; font-weight: bold; font-size:16px; display:inline-block;
}
.nextSlideFlight{
position:relative; background-color:#60d9ec; padding:25px 10px 25px 10px; vertical-align:middle; margin:0px; cursor: pointer; color:#1792bc; font-weight:bold; font-size:16px;display:inline-block;
}
.nextSlideFlight:hover{
position:relative; background-color:#1792bc; padding:25px 10px 25px 10px; vertical-align:middle; margin:0px; cursor: pointer; color:#ffffff; font-weight:bold; font-size:16px;display:inline-block;
}
.bxslider li a{ text-decoration:none; padding:0px; margin:0px;}
.bxslider li{ background-color:#60d9ec; height:70px; width: 100% ;margin:0px; padding:0px; vertical-align:middle; position:relative;}
.bxslider li:hover { background-color: #90f0fe; height:70px;margin:0px; padding:0px; position:relative;  }

.bxslider li a div{ padding:0px; margin:0px; font-weight:bold; color:#FF6600;height:70px; padding-top:15px;border-left:1px #999999 solid;border-right:1px #999999 solid;}
.bxslider li a div:hover{ padding:0px; margin:0px; font-weight:bold; color:#FF6600;height:70px; padding-top:15px;border-left:1px #999999 solid;border-right:1px #999999 solid; }
.bxslider li a div:hover h5{ padding-bottom:5px; margin:0px; font-weight:bold; color: #db283e;}
.bxslider li div h5 { padding-bottom:5px; margin:0px; font-weight:bold; color: #116291;}
.bxslider li div em{ padding:0px; margin:0px; font-weight: normal; color:#000;}
.bxslider li div span{ padding:0px; margin:0px; font-weight: bold; color:#000;}

li.slideSelected{ padding:0px; margin:0px; font-weight:bold; color:#FF6600;height:70px; border:3px #FF6600 solid; border-collapse:collapse; position:absolute; z-index:500; background-color:#90f0fe}
li.slideSelected div h5{color:#db283e;}
li.slideSelected:hover{height:70px;}
</style>
<script>
$(document).ready(function(){

var slider = $('.bxslider').bxSlider({
		    minSlides: 5,
            maxSlides: 5,
            slideWidth: 150,
            slideMargin: 0,
			moveSlides : 1,
            pager:false,
			controls : false,
			adaptiveHeight : false,
			responsive : true,
			onSliderLoad: function(currentIndex){
        					$("#bxSliderContainer").css("visibility", "visible");
							
      					}
		
	});
	slider.goToSlide(3);
	/*
	onSliderLoad : function(currentIndex){
	slider.goToSlide(6);
	});*/
	
	$('#flightNextSlide').click(function(){
      slider.goToNextSlide();
      return false;
    });

    $('#flightPrevSlide').click(function(){
      slider.goToPrevSlide();
      return false;
    });

});
</script>
<!-- =======flight result section start======= -->
<div class="panel panel-primary costumpanel boxshadow" >
<div class="panel-heading costum_panel_head" style="background:#1792bc">
    <h3 class="panel-title"><b>Flight Results</b></h3>
</div>
<div class="panel-body" style="padding:0px;">
<div>&nbsp;</div>    
<!-- ========================================================= -->
<div style="padding:0px; background: #60d9ec; width:100%; visibility:hidden" align="center" id="bxSliderContainer">

    <span id="flightPrevSlide" class="prevSlideFlight" title="previous"><</span>

<div style="padding:0px; margin:0px; vertical-align:middle; display:inline-block;">
    <ul class="bxslider" style="padding:0px; margin:0px; width: 100%">
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-09&a=DPS&adult=1&child=0&infant=0" title="Sab, 09 Agu 2014">								
          <div>
          <h5>Sat, 01 Agu 2014</h5>
          <em>from</em> <span>IDR 1.251.200,00</span>
          </div>
      </a>
      </li>
      <li>
        <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Sat,09 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li class="slideSelected">
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Sun, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Mon, 11 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      	<a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
      <li>
      <a href="http://www.tiket.com/pesawat/cari?d=JKT&date=2014-08-10&a=DPS&adult=1&child=0&infant=0" title="Min, 10 Agu 2014">								
          <div>
          <h5>Min, 10 Agu 2014</h5>
          <em>from</em> <span>IDR 589.300,00</span>
          </div>
        </a>
      </li>
    </ul>
</div>

    <span id="flightNextSlide" class="nextSlideFlight" title="next">></span>
   
</div>
</div>

<table border="0" cellpadding="0" cellspacing="0" id="flight-header" class="table">
			<thead>
				<tr>
					<th class="flights" rel="flights">Pesawat</th>
					<th class="depart" rel="depart">Pergi</th>
					<th class="arrival" rel="arrival">Tiba</th>
					<th class="allowance" rel="allowance">Fasilitas</th>
					<th class="price" rel="price">Harga</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<th class="flights" rel="flights">Pesawat</th>
					<th class="depart" rel="depart">Pergi</th>
					<th class="arrival" rel="arrival">Tiba</th>
					<th class="allowance" rel="allowance">Fasilitas</th>
					<th class="price" rel="price">Harga</th>
				</tr>
			</tbody>
		</table>
        
<!-- ========================================================= -->        
        <div style="height:600px;">&nbsp;</div>
       
</div>
</div>
<!-- =======flight result section start======= -->
 