<!-- =======Cheap Hotel Deals section start======= -->
  <div class="panel panel-primary costumpanel boxshadow" >
      <div class="panel-heading costum_panel_head" style="background:#1792bc">
        <h3 class="panel-title"><b>Cheap Hotel Deals</b></h3>
      </div>
      <div class="panel-body">
      <!-- ================hotel row 1 start================= -->
        <div class="row">
        <div class="col-xs-6 col-sm-6 col-md-6" style="border-top:1px #CCCCCC solid; border-bottom:1px #CCCCCC solid;border-right:1px #CCCCCC solid;" >
        	<div style="padding:5px;">
            <div>Nama Hotel</div>
            <div>Kota</div>
            <div>Harga</div>
            <div align="center"><img class="img-responsive" src="<?php echo base_url(); ?>assets/images/dummy-hotel.jpg" style="width:300px;" /></div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6" style="border-top:1px #CCCCCC solid; border-bottom:1px #CCCCCC solid;">
        	<div style="padding:5px;">
            <div>Nama Hotel</div>
            <div>Kota</div>
            <div>Harga</div>
            <div align="center"><img class="img-responsive" src="<?php echo base_url(); ?>assets/images/dummy-hotel.jpg" style="width:300px;" /></div>
            </div>
        </div>
        <!--
        </div>-->
      <!-- ================hotel row 1 end================= -->
      <!-- ================hotel row 2 start================= -->
        <!--<div class="row">-->
        <div class="col-xs-6 col-sm-6 col-md-6" style="border-top:1px #CCCCCC solid; border-bottom:1px #CCCCCC solid;border-right:1px #CCCCCC solid;" >
        	<div style="padding:5px;">
            <div>Nama Hotel</div>
            <div>Kota</div>
            <div>Harga</div>
           <div align="center"><img class="img-responsive" src="<?php echo base_url(); ?>assets/images/dummy-hotel.jpg" style="width:300px;" /></div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6" style="border-top:1px #CCCCCC solid; border-bottom:1px #CCCCCC solid;">
        	<div style="padding:5px;">
            <div>Nama Hotel</div>
            <div>Kota</div>
            <div>Harga</div>
            <div align="center"><img class="img-responsive" src="<?php echo base_url(); ?>assets/images/dummy-hotel.jpg" style="width:300px;" /></div>
            </div>
        </div>
        </div>
      <!-- ================hotel row 2 end================= -->
    
      </div>
</div>
  <!-- =======Cheap Hotel Deals section end======= -->
 