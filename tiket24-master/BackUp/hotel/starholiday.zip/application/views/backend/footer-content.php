<div id="footerImageLogo">&nbsp;</div>
<div style="display:inline-block; vertical-align:top;">
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
<td id="footCol1">
<div style="font-weight:bold; color:#005589;">About Us</div>
<div>Carrers</div>
<div>Corporate Profile</div>
<div>Terms and Conditions</div>
</td>
<td id="footCol2">
<div style="font-weight:bold;color:#005589;">Contact Us</div>
<div>Call Centre</div>
<div>Sales Office</div>
</td>
<td id="footCol3">
<div style="font-weight:bold;color:#005589;">Our Channels</div>
<div>Facebook</div>
<div>Twitter</div>
<div>Instagram</div>
</td>
<td id="footCol4">
<div style="font-weight:bold;color:#005589;">Our Office</div>
<div>Jl. Soekarno-Hatta No.400 Bandung - Indonesia</div>
<div>Phone : +62 22 2963 3600</div>
<div>Fax. : +62 22 2963 3600</div>
</td>
</tr>
</table>
</div>